package GenericsLab.ArrayCreator;

public class Main {
    public static void main(String[] args) {
        String[] random = ArrayCreator.create(5,"Boxing");
        Integer[] number = ArrayCreator.create(Integer.class,7,7);
    }
}
