package university;

import java.util.ArrayList;
import java.util.List;

public class University {
    private List<Student> students;
    private int capacity;

    public University(int capacity) {
        this.capacity = capacity;
        this.students = new ArrayList<>();
    }

    public int getCapacity() {
        return capacity;
    }

    public List<Student> getStudents() {
        return students;
    }

    public int getStudentCount() {
        return students.size();
    }

    public String registerStudent(Student student) {
        if (getStudentCount() < capacity) {
            if (students.contains(student)) {
                return "Student is already in the university";
            } else {
                students.add(student);
                return "Added student" + " " + student.getFirstName() + " " + student.getLastName();
            }
        }
           return "No seats in the university";
    }

    public String dismissStudent(Student student) {
        Student studentFound  = getStudent(student.getFirstName(), student.getLastName());
        if (studentFound == null) {
            return "Student not found";
        }
        students.remove(student);
        return "Removed student " + student.getFirstName() + " " + student.getLastName();
        }

    public Student getStudent(String firstName, String lastName) {
        for (Student student : students) {
            if (student.getFirstName().equals(firstName) && student.getLastName().equals(lastName)) {
                return student;
            }
        }
        return null;
    }

    public String getStatistics() {
        StringBuilder sb = new StringBuilder();
        for (Student student:students) {
            sb.append(String.format("==Student: First Name = %s, Last Name = %s, Best Subject = %s"
            , student.getFirstName(), student.getLastName(), student.getBestSubject())).append(System.lineSeparator());
        }
        return sb.toString().trim();
    }

}
