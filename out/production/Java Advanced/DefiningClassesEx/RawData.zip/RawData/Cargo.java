package DefiningClassesEx.RawData;

public class Cargo {

    private String cargoType;

    public Cargo(String cargoType) {

        this.cargoType = cargoType;
    }

    public void setCargoType(String cargoType) {
        this.cargoType = cargoType;
    }

    public String getCargoType() {
        return cargoType;
    }
}
