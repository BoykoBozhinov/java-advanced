package DefiningClassesEx.RawData;

public class Engine {

    private int enginePower;

    public Engine(int enginePower) {

        this.enginePower = enginePower;
    }

    public void setEnginePower(int enginePower) {
        this.enginePower = enginePower;
    }

    public int getEnginePower() {
        return enginePower;
    }
}
